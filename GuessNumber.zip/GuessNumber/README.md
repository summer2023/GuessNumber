# 作业
- 完成Game、Number、NumberGenerator的测试
- 截止时间2017年1月19号晚
- 最好注册github然后把代码放到线上，把项目地址发到 txku@thoughtworks.com

# 如何写测试用例：
- edge case
- common case

### 测试用例1：
- 是否4位字符
- 是否都是数字
3. 是否每位数字都不重复

### 测试用例2：
- 完全相同的数字比较，是否返回4A0B
- 完全不同的数字比较，是否返回0A0B
- 数字相同，但是每位都不同的情况，是否返回0A4B
- ...
