package com.tw.practice;

import org.junit.Test;

import static org.junit.Assert.*;

public class NumberTest {

    private Number number=new Number("1234");

    @Test
    public void shouldReturn4A0BWhenHasSameNumber() {
        String resultAllSame=number.compare("1234");
        assertEquals("4A0B",resultAllSame);
    }

    @Test
    public void shouldReturn0A0BWhenHasTotallyDifferentNumber() {
        String resultAllDifferent=number.compare("5678");
        assertEquals("0A0B",resultAllDifferent);
    }

    @Test
    public void shouldReturn0A4BWhenHasSameNumberDifferntLocation() {
        String resultSameNumberDifferentLocation=number.compare("4321");
        assertEquals("0A4B",resultSameNumberDifferentLocation);
    }

    @Test
    public void vaildWhennormally() {
        String resultSameNumberDifferentLocation=number.compare("3526");
        assertEquals("0A2B",resultSameNumberDifferentLocation);
    }
}