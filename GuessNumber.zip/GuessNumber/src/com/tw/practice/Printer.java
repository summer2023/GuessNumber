package com.tw.practice;

public class Printer {
    public void print(String message) {
        System.out.println(message);
    }
}
